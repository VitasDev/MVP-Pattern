# MVP sample
Clear MVP sample for beginners, without any interfaces and libraries
